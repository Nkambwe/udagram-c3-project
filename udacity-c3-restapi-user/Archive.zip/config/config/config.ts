export const config = {
  "dev": {
    "username": "udgramnkambwedev",
    "password": "skylite=2011",
    "database": "udgramnkambwedev",
    "host": "udgramnkambwedev.c5zwmtlztbwe.us-east-1.rds.amazonaws.com",
    "dialect": "postgres",
  },
  "aws": {
    "aws_region": "us-east-1",
    "aws_profile": "default",
    "aws_media_bucket": "udagram-nkambw-dev"
  },
  "jwt":{
    "secret":"mysecret"
  }
}
